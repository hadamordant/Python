# Sistema de Gestión Básica de productos creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
# Lista principal para almacenar todos los productos
# Estructura: [[nombre, categoría, precio], [nombre2, categoria2, precio2], ...]
productos = []

# Variable de control para el bucle principal
ejecutando = True

while ejecutando:
    # --- MENÚ PRINCIPAL ---
    print("\n" + "="*40)
    print("Agencia de Habilidades para el Futuro ARG")
    print("Curso Iniciación con Python / Comisión Nro. 25207")
    print("Realizado por Romina Betancourt CI: 16052570")
    print("Instructora: Nicki Bambacar")
    print("\n" + "="*40)
    print("Sistema de Gestión Básica De Productos")
    print("="*40)
    print("1. Agregar producto")
    print("2. Mostrar productos")
    print("3. Buscar producto")
    print("4. Eliminar producto")
    print("5. Salir")
    print("="*40)
    
    # Manejo de la opción de menú
    try:
        opcion = int(input("Seleccione una opción (1-5): "))
    except ValueError:
        print("❌ Error: Ingrese un número de opción válido.")
        continue # Vuelve al inicio del bucle

    # --- 1. Agregar producto (Opción 1) ---
    if opcion == 1:
        print("\n--- AGREGAR PRODUCTO ---")
        
        # Validación de Nombre
        while True:
            nombre = input("Ingrese nombre del producto: ").strip()
            if nombre:
                break
            print("❌ Error: El nombre no puede estar vacío.")

        # Validación de Categoría
        while True:
            categoria = input("Ingrese categoría del producto: ").strip()
            if categoria:
                break
            print("❌ Error: La categoría no puede estar vacía.")
            
        # Validación de Precio
        while True:
            try:
                precio = int(input("Ingrese precio del producto (sin centavos): "))
                if precio > 0:
                    break
                else:
                    print("❌ Error: El precio debe ser un número positivo.")
            except ValueError:
                print("❌ Error: Ingrese un número entero válido para el precio.")
        
        # Almacenar el producto
        nuevo_producto = [nombre, categoria, precio]
        productos.append(nuevo_producto)
        print(f"\n✅ Producto '{nombre}' agregado con éxito.")

    # --- 2. Mostrar productos (Opción 2) ---
    elif opcion == 2:
        print("\n--- VISUALIZACIÓN DE PRODUCTOS REGISTRADOS ---")
        if not productos:
            print("ℹ️ No hay productos registrados aún.")
        else:
            # Usando un bucle for para recorrer y enumerate para obtener el índice
            for i, producto in enumerate(productos):
                # Desempaquetado de la sublista del producto para mayor claridad
                nombre, categoria, precio = producto
                print(f"{i + 1}. Nombre: {nombre} | Categoría: {categoria} | Precio: ${precio}")
            print("---------------------------------------------")

    # --- 3. Buscar producto (Opción 3) ---
    elif opcion == 3:
        print("\n--- BUSCAR PRODUCTO ---")
        
        # Validación del término de búsqueda
        termino = ""
        while not termino:
            termino = input("Ingrese el nombre o parte del nombre a buscar: ").strip().lower()
            if not termino:
                print("❌ Error: El término de búsqueda no puede estar vacío.")
        
        resultados = []
        
        # Bucle for para buscar coincidencias
        for producto in productos:
            nombre = producto[0].lower()
            if termino in nombre:
                resultados.append(producto)

        if resultados:
            print("\n--- RESULTADOS DE BÚSQUEDA ---")
            for i, producto in enumerate(resultados):
                nombre, categoria, precio = producto
                print(f"{i + 1}. Nombre: {nombre} | Categoría: {categoria} | Precio: ${precio}")
            print("----------------------------")
        else:
            print(f"⚠️ No se encontraron productos con el término '{termino}'.")

    # --- 4. Eliminar producto (Opción 4) ---
    elif opcion == 4:
        print("\n--- ELIMINAR PRODUCTO ---")
        
        if not productos:
            print("ℹ️ No hay productos para eliminar.")
            continue
            
        # Muestra la lista antes de eliminar (duplicando código de Opción 2)
        print("--- Productos Actuales ---")
        for i, producto in enumerate(productos):
            nombre, categoria, precio = producto
            print(f"{i + 1}. Nombre: {nombre}")
        print("--------------------------")
        
        # Bucle para asegurar una entrada válida para eliminar
        while True:
            try:
                num_eliminar = int(input("Ingrese el número del producto a eliminar (0 para cancelar): "))
                
                if num_eliminar == 0:
                    print("Operación cancelada.")
                    break
                    
                indice = num_eliminar - 1

                # Validación del rango
                if 0 <= indice < len(productos):
                    nombre_eliminado = productos[indice][0]
                    productos.pop(indice)
                    print(f"✅ Producto '{nombre_eliminado}' eliminado con éxito.")
                    break
                else:
                    print("❌ Error: Número de producto inválido. Intente de nuevo.")

            except ValueError:
                print("❌ Error: Ingrese un número entero válido.")

    # --- 5. Salir (Opción 5) ---
    elif opcion == 5:
        print("\n👋 ¡Gracias por usar el Sistema de Gestión de Productos! Saliendo...")
        ejecutando = False # Cambia la variable de control para terminar el bucle

    # --- Opción no válida ---
    else:
        print("⚠️ Opción no válida. Por favor, elija un número del 1 al 5.")