# Clase 3: Estructuras Condicionales Compuestas (if con and/or)
# Este código busca verificar si una persona puede "ingresar" (lógica de verificación de edad) y luego si ha llenado completamente un formulario (lógica de validación de formulario).
# Creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
print("\n" + "="*40)
print("Agencia de Habilidades para el Futuro ARG")
print("Curso Iniciación con Python / Comisión Nro. 25207")
print("Realizado por Romina Betancourt CI: 16052570")
print("Instructora: Nicki Bambacar")
print("="*40)
print(" Porgrama que busca verificar si una persona puede ingresar por validación de edades y luego si ha llenado completamente un formulario.")
# 1. Verificación de edad (bloque inicial)
# Se usa int() para convertir la entrada de la edad en un número entero
edad = int(input("Ingresa tu edad:"))

if edad >= 18 and edad <= 30:
    # Si la edad está entre 18 y 30 (ambos incluidos)
    print("Podes ingresar")
else:
    # Si no cumple el rango de edad
    print("No podes ingresar")

# 2. Solicitud de datos del formulario (se ejecuta independientemente del bloque anterior)
# Nota: La edad se solicita de nuevo aquí, lo cual es redundante y se corrige.
# Se asume que en el código original es un error o es parte de un ejercicio separado.
# Para fines de la lógica del formulario, usaré las variables ya declaradas.
# *** CORRECCIÓN: Se elimina la línea 9: edad = int(input("Ingresa su edad:")) ***

nombre = input("Ingrese su nombre:")
apellido = input("Ingrese su apellido:")
email = input("Ingrese su email:")

# 3. Verificación de formulario (bloque condicional compuesto)
# La condición original es: if nombre != "" and apellido != "" and email != "" and edad >= 18:
# El != "" (diferente de cadena vacía) verifica que el usuario haya ingresado algo.

if nombre != "" and apellido != "" and email != "" and edad >= 18:
    print("Nombre:", nombre, ",Apellido:", apellido, ",Edad:", edad, ",Email:", email)
    # Corrección: El texto original 'InApellido' se corrige a 'Apellido'
else:
    print("ERROR") # Se ejecuta si alguna de las condiciones (nombre, apellido, email no vacío O edad < 18) falla.
print("\n" + "="*40)
# Nota de Diseño: El segundo bloque de if/else se ejecuta aunque el primer
# bloque haya impreso "No podes ingresar", y el formulario se pide
# independientemente del primer resultado, lo cual es una lógica inusual
# en una aplicación real, pero es el código tal cual se presenta.