# Clase 6: Listas (Introducción y Manipulación)
# Ejercicio Obligatorio: Gestión de Tareas Simples
# Enunciado Sugerido: Implementa un pequeño sistema que permita al usuario agregar una tarea a una lista de pendientes y mostrar todas las tareas en la lista. El programa debe permitir estas dos acciones repetidamente hasta que el usuario decida salir.
# Creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
# CLASE 6 - Listas: Gestión de Tareas Simples (Mini-Menú)
print("\n" + "="*40)
print("Agencia de Habilidades para el Futuro ARG")
print("Curso Iniciación con Python / Comisión Nro. 25207")
print("Realizado por Romina Betancourt CI: 16052570")
print("Instructora: Nicki Bambacar")
print("="*40)
print("Programa que Implementa un pequeño sistema que permite al usuario agregar una tarea a una lista de pendientes y mostrar todas las tareas en la lista. El programa debe permitir estas dos acciones repetidamente hasta que el usuario decida salir.") 
tareas = []
ejecutando_clase6 = True

while ejecutando_clase6:
    print("\n--- GESTIÓN DE TAREAS ---")
    print("1. Agregar tarea")
    print("2. Mostrar tareas pendientes")
    print("3. Salir")
    
    opcion = input("Seleccione una opción: ").strip()
    
    if opcion == '1':
        # AGREGAR TAREA
        nueva_tarea = input("Escriba la nueva tarea: ").strip()
        if nueva_tarea:
            tareas.append(nueva_tarea) # Agrega la tarea al final de la lista
            print(f"✅ Tarea '{nueva_tarea}' agregada.")
        else:
            print("❌ La tarea no puede estar vacía.")
            
    elif opcion == '2':
        # MOSTRAR TAREAS
        print("\n--- LISTA DE TAREAS PENDIENTES ---")
        if not tareas:
            print("ℹ️ No hay tareas pendientes.")
        else:
            # Usa un bucle for y enumerate para mostrar la lista numerada
            for i, tarea in enumerate(tareas):
                print(f"{i + 1}. {tarea}")
        
    elif opcion == '3':
        # SALIR
        print("👋 Finalizando el gestor de tareas.")
        ejecutando_clase6 = False
        
    else:
        print("⚠️ Opción no válida. Intente de nuevo.")