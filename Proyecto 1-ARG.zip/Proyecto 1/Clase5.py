# Clase 5: Bucles Repetitivos (for) e Iteración de Cadenas
# Ejercicio Obligatorio: Contador de Vocales
# Enunciado Sugerido: Pide al usuario que ingrese una frase o palabra. Luego, usa el bucle for para contar cuántas vocales (a, e, i, o, u), tanto mayúsculas como minúsculas, contiene la frase.
# Creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
print("\n" + "="*40)
print("Agencia de Habilidades para el Futuro ARG")
print("Curso Iniciación con Python / Comisión Nro. 25207")
print("Realizado por Romina Betancourt CI: 16052570")
print("Instructora: Nicki Bambacar")
print("="*40)
print("Programa que pide al usuario que ingrese una frase o palabra. Luego, usa el bucle for para contar cuántas vocales (a, e, i, o, u), tanto mayúsculas como minúsculas, contiene la frase.")
# CLASE 5 - Bucle For: Contador de Vocales

print("--- CONTADOR DE VOCALES ---")
frase = input("Ingrese una frase: ").strip()

contador_vocales = 0
vocales = "aeiouáéíóú" # Definimos las vocales a buscar

# Recorremos la frase con un bucle for
for letra in frase:
    # Convertimos la letra a minúscula para la comparación
    letra_minuscula = letra.lower()
    
    # Comprobamos si la letra está en nuestra cadena 'vocales'
    if letra_minuscula in vocales:
        contador_vocales = contador_vocales + 1

# Muestra el resultado
print(f"La frase ingresada fue: '{frase}'")
print(f"Número total de vocales encontradas: {contador_vocales} 🎤")