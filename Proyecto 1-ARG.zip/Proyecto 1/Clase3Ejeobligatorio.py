# Clase 3: Estructuras Condicionales Compuestas (if con and/or)
# Ejercicio Obligatorio Sugerido: Lógica de Acceso al Sistemaformulario (lógica de validación de formulario).
# Enunciado: Crea un programa que pida un nombre de usuario y una contraseña. El acceso será concedido solo si el nombre de usuario es "admin" Y la contraseña es "p4ssw0rd". Si no, el acceso será denegado.
# Creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
print("\n" + "="*40)
print("Agencia de Habilidades para el Futuro ARG")
print("Curso Iniciación con Python / Comisión Nro. 25207")
print("Realizado por Romina Betancourt CI: 16052570")
print("Instructora: Nicki Bambacar")
print("="*40)
# Ejercicio Obligatorio - Lógica de Acceso al Sistema

# Definición de credenciales correctas
USUARIO_CORRECTO = "admin"
PASSWORD_CORRECTO = "p4ssw0rd"
print("Programa Validador de Credenciales Usuario y Contraseña")
# 1. Solicitar las credenciales.
usuario = input("Ingrese nombre de usuario: ")
contrasena = input("Ingrese contraseña: ")

# 2. Aplicar el condicional compuesto con el operador AND.
if usuario == USUARIO_CORRECTO and contrasena == PASSWORD_CORRECTO:
    print("✅ Acceso concedido. Bienvenido/a al sistema.")
else:
    print("❌ Acceso denegado. Usuario o contraseña incorrectos.")