# Clase 7: Métodos de Listas y Acceso por Índice
# Ejercicio Obligatorio: Gestión de Inventario Básico
# Enunciado Sugerido: Partiendo de una lista inicial de productos (cadenas de texto), permite al usuario realizar dos acciones de gestión de inventario: eliminar un producto por su nombre y modificar el nombre de un producto existente.
# Creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
# CLASE 7 - Listas: Gestión de Inventario Básico
print("\n" + "="*40)
print("Agencia de Habilidades para el Futuro ARG")
print("Curso Iniciación con Python / Comisión Nro. 25207")
print("Realizado por Romina Betancourt CI: 16052570")
print("Instructora: Nicki Bambacar")
print("="*40)
print("Programa que permite al usuario realizar dos acciones de gestión de inventario de una lista creada de Inventario de Productos: eliminar un producto por su nombre y modificar el nombre de un producto existente.")
# Lista inicial de ejemplo
inventario = ["Leche", "Pan", "Huevos", "Cereal", "Café"]
ejecutando_clase7 = True

while ejecutando_clase7:
    print("\n--- INVENTARIO ACTUAL ---")
    if not inventario:
        print("El inventario está vacío.")
    else:
        print(inventario)
        
    print("\n--- ACCIONES ---")
    print("1. Eliminar producto por nombre")
    print("2. Modificar nombre de producto")
    print("3. Salir")
    
    opcion = input("Seleccione una opción: ").strip()

    # --- 1. Eliminar producto ---
    if opcion == '1':
        if not inventario:
             print("No hay productos para eliminar.")
             continue
             
        nombre_a_eliminar = input("Ingrese el nombre del producto a ELIMINAR: ").strip()
        try:
            # Usando el método .remove()
            inventario.remove(nombre_a_eliminar) 
            print(f"✅ Producto '{nombre_a_eliminar}' eliminado.")
        except ValueError:
            # .remove() lanza ValueError si el elemento no existe
            print(f"❌ Error: El producto '{nombre_a_eliminar}' no se encontró en el inventario.")

    # --- 2. Modificar nombre ---
    elif opcion == '2':
        if not inventario:
             print("No hay productos para modificar.")
             continue
             
        nombre_antiguo = input("Ingrese el nombre del producto a MODIFICAR: ").strip()
        
        try:
            # 1. Encontrar el índice del producto
            indice = inventario.index(nombre_antiguo)
            
            # 2. Solicitar el nuevo nombre
            nombre_nuevo = input(f"Ingrese el nuevo nombre para '{nombre_antiguo}': ").strip()
            
            if nombre_nuevo:
                # 3. Modificar la lista usando el acceso por índice
                inventario[indice] = nombre_nuevo
                print(f"✅ Producto modificado: '{nombre_antiguo}' ahora es '{nombre_nuevo}'.")
            else:
                print("❌ El nuevo nombre no puede estar vacío.")
                
        except ValueError:
            # .index() lanza ValueError si el elemento no existe
            print(f"❌ Error: El producto '{nombre_antiguo}' no se encontró en el inventario.")

    # --- 3. Salir ---
    elif opcion == '3':
        print("👋 Finalizando la gestión de inventario.")
        ejecutando_clase7 = False
        
    else:
        print("⚠️ Opción no válida. Intente de nuevo.")