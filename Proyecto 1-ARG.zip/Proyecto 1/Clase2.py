# Ejercicio Obligatorio - Calificación de Notas
# Clase 2: Estructuras Condicionales (if, elif, else)
# Escribe un programa que pida al usuario una nota (número entero del 0 al 100) y muestre un mensaje de clasificación según los siguientes rangos:
# 0-59: "Necesitas estudiar más."
# 60-79: "Aprobado, buen trabajo."
# 80-100: "Sobresaliente, ¡felicidades!"
# Cualquier otro valor: "Nota inválida."
# Creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
print("\n" + "="*40)
print("Agencia de Habilidades para el Futuro ARG")
print("Curso Iniciación con Python / Comisión Nro. 25207")
print("Realizado por Romina Betancourt CI: 16052570")
print("Instructora: Nicki Bambacar")
print("="*40)
print("Programa que pida al usuario una nota (número entero del 0 al 100) y muestre un mensaje de clasificación según los siguientes rangos:")
print("Necesitas estudiar más.") 
print("0-59:")
print("60-79: Aprobado buen trabajo.")
print("80-100: Sobresaliente, felicidades")
print("Cualquier otro valor: Nota inválida.")
try:
    # 1. Solicitar la nota y convertirla a entero.
    nota = int(input("Ingrese su nota (0-100): "))

    # 2. Aplicar las condiciones lógicas (elif y else para múltiples caminos).
    if 80 <= nota <= 100:
        print("Sobresaliente, ¡felicidades! 🌟")
    elif 60 <= nota <= 79:
        print("Aprobado, buen trabajo. 👍")
    elif 0 <= nota <= 59:
        print("Necesitas estudiar más. 😟")
    else:
        # Condición para notas fuera del rango 0-100.
        print("Nota inválida. Por favor, ingrese un número entre 0 y 100.")

except ValueError:
    print("Error: Ingrese solo números enteros para la nota.")