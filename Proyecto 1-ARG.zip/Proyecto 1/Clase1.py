# Clase 1: Variables y Entrada de Datos (input)
# Este código solicita el nombre, apellido, edad y correo electrónico para luego mostrar una "tarjeta de presentación".
# Creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
print("\n" + "="*40)
print("Agencia de Habilidades para el Futuro ARG")
print("Curso Iniciación con Python / Comisión Nro. 25207")
print("Realizado por Romina Betancourt CI: 16052570")
print("Instructora: Nicki Bambacar")
print("="*40)
print("Programa que solicita el Nombre, Apellido, Edad y Correo Electrónico para luego mostrar una Tarjeta de Presentación")
nombre = input("Ingrese Nombre: ")
apellido = input("Ingrese Apellido: ")
# Corrección: El valor de la edad debe ser convertido a entero (int)
# si se va a usar en operaciones matemáticas o comparaciones lógicas.
# Aunque para solo imprimirlo, input() es suficiente, es buena práctica
# para datos numéricos. Lo mantengo como input() ya que en la Clase 3 se
# pide int(), y se asume aquí solo se imprime.
edad = input("Ingrese Edad: ")
email = input("Ingrese Correo Electrónico: ")

print("\n---Tarjeta de Presentacion---")
# Usando una f-string (disponible desde Python 3.6) para formatear la impresión.
# En el código original se usa coma (,) para separar los argumentos en print(),
# lo cual es perfectamente válido.
print(f"Nombre Completo: {nombre} {apellido}")
print(f"Edad: {edad}")
print(f"Correo Electrónico: {email}")
print("------------------------------")