# Clase 4: Bucles Repetitivos (while)
# Ejercicio Obligatorio: Sumador Interactivo
# Enunciado Sugerido: Escribe un programa que pida al usuario números indefinidamente. El programa debe sumar los números ingresados y detenerse solo cuando el usuario ingrese el número cero (0). Al finalizar, debe mostrar la suma total y cuántos números se ingresaron.
# Creado por Romina Betancourt CI: 16052570
# Para el Curso Iniciación con Python / Comisión Nro.25207
# Instructora: Nicki Bambacar
print("\n" + "="*40)
print("Agencia de Habilidades para el Futuro ARG")
print("Curso Iniciación con Python / Comisión Nro. 25207")
print("Realizado por Romina Betancourt CI: 16052570")
print("Instructora: Nicki Bambacar")
print("="*40)
# CLASE 4 - Bucle While: Sumador Interactivo
print("Escribe un programa que pida al usuario números indefinidamente. El programa debe sumar los números ingresados y detenerse solo cuando el usuario ingrese el número cero (0). Al finalizar, debe mostrar la suma total y cuántos números se ingresaron")
print("--- SUMADOR INTERACTIVO ---")
print("Ingrese números para sumarlos. Ingrese 0 para finalizar.")

suma_total = 0
contador = 0

# Bucle while: se ejecuta mientras el número ingresado no sea 0
while True:
    try:
        # Pide la entrada y la convierte a entero
        numero = int(input(f"Ingrese número #{contador + 1}: "))
        
        if numero == 0:
            # Condición de salida del bucle
            break
            
        suma_total = suma_total + numero
        contador = contador + 1

    except ValueError:
        print("❌ Error: Ingrese solo números enteros.")
        # El bucle continua si hay error
        
# Muestra los resultados finales
if contador > 0:
    print(f"\n✅ Proceso finalizado.")
    print(f"Suma total de los {contador} números ingresados: {suma_total}")
else:
    print("No se ingresaron números válidos (solo el 0).")